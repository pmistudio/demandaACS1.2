import streamlit as st
import pandas as pd
import numpy as np

st.set_page_config(page_title="Calculadora ACS CTE-DB-HE4", page_icon="💧", layout="centered")
st.title("Calculadora de Demanda de Agua Caliente Sanitaria (ACS)")
st.markdown("Esta aplicación calcula la demanda diaria de ACS según el CTE-DB-HE4.")

tabla_a = pd.DataFrame({
    'Número de dormitorios': [1, 2, 3, 4, 5, 6, '≥6'],
    'Número de personas': [1.5, 3, 4, 5, 6, 6, 7]
})

tabla_b = pd.DataFrame({
    'Número de viviendas': ['≤3', '4-10', '11-20', '21-50', '51-75', '76-100', '≥101'],
    'Factor de centralización': [1, 0.95, 0.90, 0.85, 0.80, 0.75, 0.70]
})

tabla_c = pd.DataFrame({
    'Criterio de demanda': [
        'Hospitales y clínicas', 'Ambulatorio y centro de salud', 'Hotel *****',
        'Hotel ****', 'Hotel ***', 'Hotel/hostal **', 'Camping', 'Hostal/pensión *',
        'Residencia', 'Centro penitenciario', 'Albergue', 'Vestuarios/duchas colectivas',
        'Escuela sin ducha', 'Escuela con ducha', 'Cuarteles', 'Fábricas y talleres',
        'Oficinas', 'Gimnasios', 'Restaurantes', 'Cafeterías'
    ],
    'Litros/día·persona': [
        55, 41, 69, 55, 41, 34, 21, 28, 41, 28, 24, 21, 4, 21, 28, 21, 2, 21, 8, 1
    ]
})

with st.form("formulario_acs"):
    tipo_uso = st.radio("Tipo de uso:", ["Residencial", "Terciario"], index=0, horizontal=True)
    if tipo_uso == "Residencial":
        num_dormitorios = st.number_input("Número de dormitorios:", min_value=1, max_value=10, value=2)
        tipo_edificacion = st.radio("Tipo de edificación:", ["Unifamiliar", "Colectiva"], index=0, horizontal=True)
        num_viviendas = None
        if tipo_edificacion == "Colectiva":
            num_viviendas = st.number_input("Número de viviendas:", min_value=1, max_value=200, value=10)
    else:
        criterio_terciario = st.selectbox("Criterio de demanda:", tabla_c['Criterio de demanda'].tolist())
        num_personas_terciario = st.number_input("Número de personas/usuarios:", min_value=1, value=10)
    temp_servicio = st.slider("Temperatura de servicio (°C):", min_value=30, max_value=90, value=60)
    submitted = st.form_submit_button("Calcular demanda ACS")

def obtener_personas(dormitorios):
    if dormitorios >= 6:
        return 7
    return tabla_a.loc[tabla_a['Número de dormitorios'] == dormitorios, 'Número de personas'].values[0]

def obtener_factor_centralizacion(viviendas):
    if viviendas <= 3: return 1
    elif viviendas <= 10: return 0.95
    elif viviendas <= 20: return 0.90
    elif viviendas <= 50: return 0.85
    elif viviendas <= 75: return 0.80
    elif viviendas <= 100: return 0.75
    else: return 0.70

def obtener_litros_terciario(criterio):
    return tabla_c.loc[tabla_c['Criterio de demanda'] == criterio, 'Litros/día·persona'].values[0]

def calcular_demanda_acs(uso, dormitorios=None, edificacion=None, viviendas=None, criterio_terciario=None, personas_terciario=None, temperatura=60):
    demanda_referencia = 28
    if uso == "Residencial":
        personas = obtener_personas(dormitorios)
        demanda = demanda_referencia * personas
        if edificacion == "Colectiva":
            factor = obtener_factor_centralizacion(viviendas)
            demanda = demanda * viviendas * factor
    else:
        litros_persona = obtener_litros_terciario(criterio_terciario)
        demanda = litros_persona * personas_terciario
    if temperatura != 60:
        demanda = demanda * (60 - 15) / (temperatura - 15)
    return demanda

if submitted:
    try:
        if tipo_uso == "Residencial":
            demanda = calcular_demanda_acs(tipo_uso, num_dormitorios, tipo_edificacion, num_viviendas, temperatura=temp_servicio)
            st.success(f"**Demanda diaria de ACS: {demanda:.2f} L/día**")
        else:
            demanda = calcular_demanda_acs(tipo_uso, criterio_terciario=criterio_terciario, personas_terciario=num_personas_terciario, temperatura=temp_servicio)
            st.success(f"**Demanda diaria de ACS: {demanda:.2f} L/día**")
    except Exception as e:
        st.error(f"Error en el cálculo: {str(e)}")
